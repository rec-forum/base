<!DOCTYPE html>
<html dir="ltr" lang="en-gb">
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1" />

<title>Royal English Club-英文讀書會 - Index page</title>

	<link rel="alternate" type="application/atom+xml" title="Feed - Royal English Club-英文讀書會" href="http://www.royalclub.tw/bbs3/feed.php">			<link rel="alternate" type="application/atom+xml" title="Feed - New Topics" href="http://www.royalclub.tw/bbs3/feed.php?mode=topics">				

<!--
	phpBB style name: prosilver
	Based on style:   prosilver (this is the default phpBB3 style)
	Original author:  Tom Beddard ( http://www.subBlue.com/ )
	Modified by:
-->

<link href="./styles/prosilver/theme/stylesheet.css?assets_version=1" rel="stylesheet">
<link href="./styles/prosilver/theme/en/stylesheet.css?assets_version=1" rel="stylesheet">
<link href="./styles/prosilver/theme/responsive.css?assets_version=1" rel="stylesheet" media="all and (max-width: 700px)">



<!--[if lte IE 9]>
	<link href="./styles/prosilver/theme/tweaks.css?assets_version=1" rel="stylesheet">
<![endif]-->





</head>
<body id="phpbb" class="nojs notouch section-index ltr ">


<div id="wrap">
	<a id="top" class="anchor" accesskey="t"></a>
	<div id="page-header">
		<div class="headerbar" role="banner">
			<div class="inner">

			<div id="site-description">
				<a id="logo" class="logo" href="./index.php?sid=db25550c72854578cb53ba86598c166f" title="Board index"><span class="imageset site_logo"></span></a>
				<h1>Royal English Club-英文讀書會</h1>
				<p>輕鬆學習! 放鬆學習! 結交朋友!</p>
				<p class="skiplink"><a href="#start_here">Skip to content</a></p>
			</div>

									<div id="search-box" class="search-box search-header" role="search">
				<form action="./search.php?sid=db25550c72854578cb53ba86598c166f" method="get" id="search">
				<fieldset>
					<input name="keywords" id="keywords" type="search" maxlength="128" title="Search for keywords" class="inputbox search tiny" size="20" value="" placeholder="Search…" />
					<button class="button icon-button search-icon" type="submit" title="Search">Search</button>
					<a href="./search.php?sid=db25550c72854578cb53ba86598c166f" class="button icon-button search-adv-icon" title="Advanced search">Advanced search</a>
					<input type="hidden" name="sid" value="db25550c72854578cb53ba86598c166f" />

				</fieldset>
				</form>
			</div>
			
			</div>
		</div>
				<div class="navbar" role="navigation">
	<div class="inner">

	<ul id="nav-main" class="linklist bulletin" role="menubar">

		<li id="quick-links" class="small-icon responsive-menu dropdown-container" data-skip-responsive="true">
			<a href="#" class="responsive-menu-link dropdown-trigger">Quick links</a>
			<div class="dropdown hidden">
				<div class="pointer"><div class="pointer-inner"></div></div>
				<ul class="dropdown-contents" role="menu">
					
											<li class="separator"></li>
																								<li class="small-icon icon-search-unanswered"><a href="./search.php?search_id=unanswered&amp;sid=db25550c72854578cb53ba86598c166f" role="menuitem">Unanswered topics</a></li>
						<li class="small-icon icon-search-active"><a href="./search.php?search_id=active_topics&amp;sid=db25550c72854578cb53ba86598c166f" role="menuitem">Active topics</a></li>
						<li class="separator"></li>
						<li class="small-icon icon-search"><a href="./search.php?sid=db25550c72854578cb53ba86598c166f" role="menuitem">Search</a></li>
					
											<li class="separator"></li>
												<li class="small-icon icon-team"><a href="./memberlist.php?mode=team&amp;sid=db25550c72854578cb53ba86598c166f" role="menuitem">The team</a></li>										<li class="separator"></li>

									</ul>
			</div>
		</li>

				<li class="small-icon icon-faq" data-skip-responsive="true"><a href="./faq.php?sid=db25550c72854578cb53ba86598c166f" rel="help" title="Frequently Asked Questions" role="menuitem">FAQ</a></li>
						
			<li class="small-icon icon-logout rightside"  data-skip-responsive="true"><a href="./ucp.php?mode=login&amp;sid=db25550c72854578cb53ba86598c166f" title="Login" accesskey="x" role="menuitem">Login</a></li>
					<li class="small-icon icon-register rightside" data-skip-responsive="true"><a href="./ucp.php?mode=register&amp;sid=db25550c72854578cb53ba86598c166f" role="menuitem">Register</a></li>
						</ul>

	<ul id="nav-breadcrumbs" class="linklist navlinks" role="menubar">
						<li class="small-icon icon-home breadcrumbs">
									<span class="crumb" itemtype="http://data-vocabulary.org/Breadcrumb" itemscope=""><a href="./index.php?sid=db25550c72854578cb53ba86598c166f" accesskey="h" data-navbar-reference="index" itemprop="url"><span itemprop="title">Board index</span></a></span>
								</li>
		
					<li class="rightside responsive-search" style="display: none;"><a href="./search.php?sid=db25550c72854578cb53ba86598c166f" title="View the advanced search options" role="menuitem">Search</a></li>
			</ul>

	</div>
</div>
	</div>

	
	<a id="start_here" class="anchor"></a>
	<div id="page-body" role="main">
		
		
<p class="right responsive-center time">It is currently Tue May 16, 2023 8:22 pm</p>



	
				<div class="forabg">
			<div class="inner">
			<ul class="topiclist">
				<li class="header">
										<dl class="icon">
						<dt><div class="list-inner"><a href="./viewforum.php?f=1&amp;sid=db25550c72854578cb53ba86598c166f">Royal English Club-英文讀書會</a></div></dt>
						<dd class="topics">Topics</dd>
						<dd class="posts">Posts</dd>
						<dd class="lastpost"><span>Last post</span></dd>
					</dl>
									</li>
			</ul>
			<ul class="topiclist forums">
		
	
	
	
			
					<li class="row">
						<dl class="icon forum_read">
				<dt title="No unread posts">
										<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Royal台北星期四文章" href="http://www.royalclub.tw/bbs3/feed.php?f=3"><img src="./styles/prosilver/theme/images/feed.gif" alt="Feed - Royal台北星期四文章" /></a> -->
												<a href="./viewforum.php?f=3&amp;sid=db25550c72854578cb53ba86598c166f" class="forumtitle">Royal台北星期四文章</a>
																		
												<div class="responsive-show" style="display: none;">
															Topics: <strong>321</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">321 <dfn>Topics</dfn></dd>
					<dd class="posts">329 <dfn>Posts</dfn></dd>
					<dd class="lastpost"><span>
												<dfn>Last post</dfn>
																				<a href="./viewtopic.php?f=3&amp;p=758&amp;sid=db25550c72854578cb53ba86598c166f#p758" title="5/18(Thu) Equal-gender racing team plots F1 entry in 2026/ Airline Passenger Behavior (Host: Jenny)" class="lastsubject">5/18(Thu) Equal-gender racing…</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=38674&amp;sid=db25550c72854578cb53ba86598c166f" class="username">Louie Wang</a>
						<a href="./viewtopic.php?f=3&amp;p=758&amp;sid=db25550c72854578cb53ba86598c166f#p758"><span class="imageset icon_topic_latest" title="View the latest post">View the latest post</span></a> <br />Mon May 15, 2023 3:31 pm</span>
					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl class="icon forum_read">
				<dt title="No unread posts">
										<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Royal板橋星期六,日文章" href="http://www.royalclub.tw/bbs3/feed.php?f=4"><img src="./styles/prosilver/theme/images/feed.gif" alt="Feed - Royal板橋星期六,日文章" /></a> -->
												<a href="./viewforum.php?f=4&amp;sid=db25550c72854578cb53ba86598c166f" class="forumtitle">Royal板橋星期六,日文章</a>
																		
												<div class="responsive-show" style="display: none;">
															Topics: <strong>327</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">327 <dfn>Topics</dfn></dd>
					<dd class="posts">328 <dfn>Posts</dfn></dd>
					<dd class="lastpost"><span>
												<dfn>Last post</dfn>
																				<a href="./viewtopic.php?f=4&amp;p=757&amp;sid=db25550c72854578cb53ba86598c166f#p757" title="5/14(Sun.) Japanese Trends: Why Are People Eating Less Rice?/ £1.3 million lottery winner went back ...(host: Amy))" class="lastsubject">5/14(Sun.) Japanese Trends: W…</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=12531&amp;sid=db25550c72854578cb53ba86598c166f" class="username">Danny Lin</a>
						<a href="./viewtopic.php?f=4&amp;p=757&amp;sid=db25550c72854578cb53ba86598c166f#p757"><span class="imageset icon_topic_latest" title="View the latest post">View the latest post</span></a> <br />Wed May 10, 2023 9:29 am</span>
					</dd>
							</dl>
					</li>
			
	
				</ul>

			</div>
		</div>
	
				<div class="forabg">
			<div class="inner">
			<ul class="topiclist">
				<li class="header">
										<dl class="icon">
						<dt><div class="list-inner">Forum</div></dt>
						<dd class="topics">Topics</dd>
						<dd class="posts">Posts</dd>
						<dd class="lastpost"><span>Last post</span></dd>
					</dl>
									</li>
			</ul>
			<ul class="topiclist forums">
		
					<li class="row">
						<dl class="icon forum_read">
				<dt title="No unread posts">
										<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Royal English Club 介紹" href="http://www.royalclub.tw/bbs3/feed.php?f=2"><img src="./styles/prosilver/theme/images/feed.gif" alt="Feed - Royal English Club 介紹" /></a> -->
												<a href="./viewforum.php?f=2&amp;sid=db25550c72854578cb53ba86598c166f" class="forumtitle">Royal English Club 介紹</a>
						<br />如果想要參加，又拿不定主意，或有點害怕，不妨來看看貼文吧!												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>5</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">5 <dfn>Topics</dfn></dd>
					<dd class="posts">5 <dfn>Posts</dfn></dd>
					<dd class="lastpost"><span>
												<dfn>Last post</dfn>
																				<a href="./viewtopic.php?f=2&amp;p=100&amp;sid=db25550c72854578cb53ba86598c166f#p100" title="你要如何&quot;偷窺&quot;這個CLUB!" class="lastsubject">你要如何&quot;偷窺&quot;這個CLUB!</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=48&amp;sid=db25550c72854578cb53ba86598c166f" class="username">dora</a>
						<a href="./viewtopic.php?f=2&amp;p=100&amp;sid=db25550c72854578cb53ba86598c166f#p100"><span class="imageset icon_topic_latest" title="View the latest post">View the latest post</span></a> <br />Mon Nov 13, 2017 11:45 pm</span>
					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl class="icon forum_read">
				<dt title="No unread posts">
										<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Royal English Facebook粉絲專頁與留言區" href="http://www.royalclub.tw/bbs3/feed.php?f=14"><img src="./styles/prosilver/theme/images/feed.gif" alt="Feed - Royal English Facebook粉絲專頁與留言區" /></a> -->
												<a href="./viewforum.php?f=14&amp;sid=db25550c72854578cb53ba86598c166f" class="forumtitle">Royal English Facebook粉絲專頁與留言區</a>
						<br /><!-- m --><a class="postlink" href="https://www.facebook.com/royalclub.tw/">https://www.facebook.com/royalclub.tw/</a><!-- m --><br /><img class="smilies" src="./images/smilies/icon_lol.gif" alt=":lol:" title="Laughing" /> <img class="smilies" src="./images/smilies/icon_lol.gif" alt=":lol:" title="Laughing" /> <img class="smilies" src="./images/smilies/icon_lol.gif" alt=":lol:" title="Laughing" />												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>1</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">1 <dfn>Topics</dfn></dd>
					<dd class="posts">1 <dfn>Posts</dfn></dd>
					<dd class="lastpost"><span>
												<dfn>Last post</dfn>
																				<a href="./viewtopic.php?f=14&amp;p=145&amp;sid=db25550c72854578cb53ba86598c166f#p145" title="Royal English Facebook粉絲專頁" class="lastsubject">Royal English Facebook粉絲專頁</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=872&amp;sid=db25550c72854578cb53ba86598c166f" class="username">Shuman</a>
						<a href="./viewtopic.php?f=14&amp;p=145&amp;sid=db25550c72854578cb53ba86598c166f#p145"><span class="imageset icon_topic_latest" title="View the latest post">View the latest post</span></a> <br />Tue Mar 06, 2018 5:31 pm</span>
					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl class="icon forum_read_subforum">
				<dt title="No unread posts">
										<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Royal English Club Meeting place" href="http://www.royalclub.tw/bbs3/feed.php?f=8"><img src="./styles/prosilver/theme/images/feed.gif" alt="Feed - Royal English Club Meeting place" /></a> -->
												<a href="./viewforum.php?f=8&amp;sid=db25550c72854578cb53ba86598c166f" class="forumtitle">Royal English Club Meeting place</a>
																		
												<div class="responsive-show" style="display: none;">
													</div>
											</div>
				</dt>
									<dd class="topics">0 <dfn>Topics</dfn></dd>
					<dd class="posts">0 <dfn>Posts</dfn></dd>
					<dd class="lastpost"><span>
												No posts<br />&nbsp;</span>
					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl class="icon forum_read">
				<dt title="No unread posts">
										<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Royal English Club 最新活動" href="http://www.royalclub.tw/bbs3/feed.php?f=13"><img src="./styles/prosilver/theme/images/feed.gif" alt="Feed - Royal English Club 最新活動" /></a> -->
												<a href="./viewforum.php?f=13&amp;sid=db25550c72854578cb53ba86598c166f" class="forumtitle">Royal English Club 最新活動</a>
																		
												<div class="responsive-show" style="display: none;">
															Topics: <strong>4</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">4 <dfn>Topics</dfn></dd>
					<dd class="posts">4 <dfn>Posts</dfn></dd>
					<dd class="lastpost"><span>
												<dfn>Last post</dfn>
																				<a href="./viewtopic.php?f=13&amp;p=246&amp;sid=db25550c72854578cb53ba86598c166f#p246" title="2018 Royal club year-end party &amp; installation" class="lastsubject">2018 Royal club year-end part…</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=872&amp;sid=db25550c72854578cb53ba86598c166f" class="username">Shuman</a>
						<a href="./viewtopic.php?f=13&amp;p=246&amp;sid=db25550c72854578cb53ba86598c166f#p246"><span class="imageset icon_topic_latest" title="View the latest post">View the latest post</span></a> <br />Tue Dec 04, 2018 7:44 am</span>
					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl class="icon forum_read">
				<dt title="No unread posts">
										<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Royal English Club actitivities" href="http://www.royalclub.tw/bbs3/feed.php?f=9"><img src="./styles/prosilver/theme/images/feed.gif" alt="Feed - Royal English Club actitivities" /></a> -->
												<a href="./viewforum.php?f=9&amp;sid=db25550c72854578cb53ba86598c166f" class="forumtitle">Royal English Club actitivities</a>
						<br />RoyalEnglish club events												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>12</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">12 <dfn>Topics</dfn></dd>
					<dd class="posts">12 <dfn>Posts</dfn></dd>
					<dd class="lastpost"><span>
												<dfn>Last post</dfn>
																				<a href="./viewtopic.php?f=9&amp;p=251&amp;sid=db25550c72854578cb53ba86598c166f#p251" title="2018 Royal club year-end party &amp; installation" class="lastsubject">2018 Royal club year-end part…</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=872&amp;sid=db25550c72854578cb53ba86598c166f" class="username">Shuman</a>
						<a href="./viewtopic.php?f=9&amp;p=251&amp;sid=db25550c72854578cb53ba86598c166f#p251"><span class="imageset icon_topic_latest" title="View the latest post">View the latest post</span></a> <br />Mon Dec 10, 2018 9:45 pm</span>
					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl class="icon forum_read">
				<dt title="No unread posts">
										<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Learn English from Video" href="http://www.royalclub.tw/bbs3/feed.php?f=11"><img src="./styles/prosilver/theme/images/feed.gif" alt="Feed - Learn English from Video" /></a> -->
												<a href="./viewforum.php?f=11&amp;sid=db25550c72854578cb53ba86598c166f" class="forumtitle">Learn English from Video</a>
																		
												<div class="responsive-show" style="display: none;">
															Topics: <strong>8</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">8 <dfn>Topics</dfn></dd>
					<dd class="posts">8 <dfn>Posts</dfn></dd>
					<dd class="lastpost"><span>
												<dfn>Last post</dfn>
																				<a href="./viewtopic.php?f=11&amp;p=253&amp;sid=db25550c72854578cb53ba86598c166f#p253" title="How AI can save our humanity (Kai-Fu Lee | TED2018)" class="lastsubject">How AI can save our humanity …</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=827&amp;sid=db25550c72854578cb53ba86598c166f" class="username">Jason Tang</a>
						<a href="./viewtopic.php?f=11&amp;p=253&amp;sid=db25550c72854578cb53ba86598c166f#p253"><span class="imageset icon_topic_latest" title="View the latest post">View the latest post</span></a> <br />Fri Dec 14, 2018 1:21 pm</span>
					</dd>
							</dl>
					</li>
			
				</ul>

			</div>
		</div>
		


	<form method="post" action="./ucp.php?mode=login&amp;sid=db25550c72854578cb53ba86598c166f" class="headerspace">
	<h3><a href="./ucp.php?mode=login&amp;sid=db25550c72854578cb53ba86598c166f">Login</a>&nbsp; &bull; &nbsp;<a href="./ucp.php?mode=register&amp;sid=db25550c72854578cb53ba86598c166f">Register</a></h3>
		<fieldset class="quick-login">
			<label for="username"><span>Username:</span> <input type="text" tabindex="1" name="username" id="username" size="10" class="inputbox" title="Username" /></label>
			<label for="password"><span>Password:</span> <input type="password" tabindex="2" name="password" id="password" size="10" class="inputbox" title="Password" autocomplete="off" /></label>
							<a href="./ucp.php?mode=sendpassword&amp;sid=db25550c72854578cb53ba86598c166f">I forgot my password</a>
										<span class="responsive-hide">|</span> <label for="autologin">Remember me <input type="checkbox" tabindex="4" name="autologin" id="autologin" /></label>
						<input type="submit" tabindex="5" name="login" value="Login" class="button2" />
			<input type="hidden" name="redirect" value="./index.php?sid=db25550c72854578cb53ba86598c166f" />

		</fieldset>
	</form>


	<div class="stat-block online-list">
		<h3>Who is online</h3>		<p>
						In total there is <strong>1</strong> user online :: 0 registered, 0 hidden and 1 guest (based on users active over the past 5 minutes)<br />Most users ever online was <strong>263</strong> on Sun May 10, 2020 2:31 pm<br /> <br />Registered users: No registered users
			<br /><em>Legend: <a style="color:#AA0000" href="./memberlist.php?mode=group&amp;g=5&amp;sid=db25550c72854578cb53ba86598c166f">Administrators</a>, <a style="color:#00AA00" href="./memberlist.php?mode=group&amp;g=4&amp;sid=db25550c72854578cb53ba86598c166f">Global moderators</a></em>					</p>
	</div>

	<div class="stat-block birthday-list">
		<h3>Birthdays</h3>
		<p>
						No birthdays today					</p>
	</div>

	<div class="stat-block statistics">
		<h3>Statistics</h3>
		<p>
						Total posts <strong>724</strong> &bull; Total topics <strong>686</strong> &bull; Total members <strong>37</strong> &bull; Our newest member <strong><a href="./memberlist.php?mode=viewprofile&amp;u=57684&amp;sid=db25550c72854578cb53ba86598c166f" class="username">wu440317</a></strong>
					</p>
	</div>


			</div>


<div id="page-footer" role="contentinfo">
	<div class="navbar" role="navigation">
	<div class="inner">

	<ul id="nav-footer" class="linklist bulletin" role="menubar">
		<li class="small-icon icon-home breadcrumbs">
									<span class="crumb"><a href="./index.php?sid=db25550c72854578cb53ba86598c166f" data-navbar-reference="index">Board index</a></span>
					</li>
		
				<li class="rightside">All times are <abbr title="Asia/Taipei">UTC+08:00</abbr></li>
							<li class="small-icon icon-delete-cookies rightside"><a href="./ucp.php?mode=delete_cookies&amp;sid=db25550c72854578cb53ba86598c166f" data-ajax="true" data-refresh="true" role="menuitem">Delete all board cookies</a></li>
									<li class="small-icon icon-team rightside" data-last-responsive="true"><a href="./memberlist.php?mode=team&amp;sid=db25550c72854578cb53ba86598c166f" role="menuitem">The team</a></li>				<li class="small-icon icon-contact rightside" data-last-responsive="true"><a href="./memberlist.php?mode=contactadmin&amp;sid=db25550c72854578cb53ba86598c166f" role="menuitem">Contact us</a></li>	</ul>

	</div>
</div>

	<div class="copyright">
				Powered by <a href="https://www.phpbb.com/">phpBB</a>&reg; Forum Software &copy; phpBB Limited
									</div>

	<div id="darkenwrapper" data-ajax-error-title="AJAX error" data-ajax-error-text="Something went wrong when processing your request." data-ajax-error-text-abort="User aborted request." data-ajax-error-text-timeout="Your request timed out; please try again." data-ajax-error-text-parsererror="Something went wrong with the request and the server returned an invalid reply.">
		<div id="darken">&nbsp;</div>
	</div>

	<div id="phpbb_alert" class="phpbb_alert" data-l-err="Error" data-l-timeout-processing-req="Request timed out.">
		<a href="#" class="alert_close"></a>
		<h3 class="alert_title">&nbsp;</h3><p class="alert_text"></p>
	</div>
	<div id="phpbb_confirm" class="phpbb_alert">
		<a href="#" class="alert_close"></a>
		<div class="alert_text"></div>
	</div>
</div>

</div>

<div>
	<a id="bottom" class="anchor" accesskey="z"></a>
	</div>

<script type="text/javascript" src="./assets/javascript/jquery.min.js?assets_version=1"></script>
<script type="text/javascript" src="./assets/javascript/core.js?assets_version=1"></script>


<script type="text/javascript" src="./styles/prosilver/template/forum_fn.js?assets_version=1"></script>

<script type="text/javascript" src="./styles/prosilver/template/ajax.js?assets_version=1"></script>




</body>
</html>
